// Pasa a minúsculas y quita tildes: "Gastronomía " -> "gastronomia"
function normalizarTexto(valor) {
  return valor
    .trim()
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '');
}

module.exports = { normalizarTexto };
