// Envuelve controladores async para enviar cualquier error al middleware centralizado.
const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

module.exports = asyncHandler;
