// Error controlado de la aplicación: lleva su propio código HTTP.
class AppError extends Error {
  constructor(mensaje, statusCode = 500, errores = undefined) {
    super(mensaje);
    this.name = 'AppError';
    this.statusCode = statusCode;
    this.errores = errores; // opcional: detalle por campo
    this.isOperational = true;
    Error.captureStackTrace(this, this.constructor);
  }
}

module.exports = AppError;
