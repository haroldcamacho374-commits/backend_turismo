const { body } = require('express-validator');
const { INTERESES_PERMITIDOS } = require('../models/Usuario');
const { normalizarTexto } = require('../utils/texto');

const reglasActualizarPerfil = [
  body('intereses')
    .optional()
    .isArray().withMessage('"intereses" debe ser una lista, por ejemplo ["aventura","cultura"]').bail()
    .customSanitizer((lista) => [
      ...new Set(lista.map((i) => (typeof i === 'string' ? normalizarTexto(i) : i))),
    ])
    .custom((lista) => {
      const invalidos = lista.filter((i) => !INTERESES_PERMITIDOS.includes(i));
      if (invalidos.length > 0) {
        throw new Error(
          `Intereses no válidos: ${invalidos.map(String).join(', ')}. Permitidos: ${INTERESES_PERMITIDOS.join(', ')}`
        );
      }
      return true;
    }),

  // null limpia el presupuesto
  body('presupuesto')
    .optional({ values: 'null' })
    .isInt({ min: 0, max: 100000000 })
    .withMessage('El presupuesto debe ser un número entero en pesos colombianos (COP), entre 0 y 100.000.000')
    .toInt(),
];

module.exports = { reglasActualizarPerfil };
