const { body } = require('express-validator');
const Usuario = require('../models/Usuario');

const reglasRegistro = [
  body('nombre')
    .notEmpty().withMessage('El nombre es obligatorio').bail()
    .isString().withMessage('El nombre debe ser texto').bail()
    .trim()
    .isLength({ min: 2, max: 80 }).withMessage('El nombre debe tener entre 2 y 80 caracteres'),

  body('correo')
    .notEmpty().withMessage('El correo es obligatorio').bail()
    .isString().withMessage('El correo debe ser texto').bail()
    .trim()
    .toLowerCase()
    .isEmail().withMessage('Ingresa un correo electrónico válido').bail()
    .custom(async (correo) => {
      const existe = await Usuario.exists({ correo });
      if (existe) throw new Error('Este correo ya está registrado');
      return true;
    }),

  body('contrasena')
    .notEmpty().withMessage('La contraseña es obligatoria').bail()
    .isString().withMessage('La contraseña debe ser texto').bail()
    .isLength({ min: 8, max: 72 }).withMessage('La contraseña debe tener entre 8 y 72 caracteres').bail()
    .matches(/[A-Z]/).withMessage('La contraseña debe incluir al menos una letra mayúscula').bail()
    .matches(/\d/).withMessage('La contraseña debe incluir al menos un número'),
];

const reglasLogin = [
  body('correo')
    .notEmpty().withMessage('El correo es obligatorio').bail()
    .isString().withMessage('El correo debe ser texto').bail()
    .trim()
    .toLowerCase()
    .isEmail().withMessage('Ingresa un correo electrónico válido'),

  body('contrasena')
    .notEmpty().withMessage('La contraseña es obligatoria').bail()
    .isString().withMessage('La contraseña debe ser texto').bail()
    .isLength({ max: 72 }).withMessage('La contraseña no puede superar los 72 caracteres'),
];

module.exports = { reglasRegistro, reglasLogin };
