const { param } = require('express-validator');
const AppError = require('../utils/AppError');

// Exige que el body traiga al menos uno de los campos indicados.
function exigirAlgunCampo(campos, { aceptarNull = false } = {}) {
  return (req, _res, next) => {
    const body = req.body || {};
    const hayDato = campos.some((campo) => {
      const valor = body[campo];
      if (valor === undefined || valor === '') return false;
      if (valor === null) return aceptarNull;
      return true;
    });
    if (hayDato) return next();
    next(
      new AppError('Datos de entrada inválidos', 400, [
        { campo: 'body', mensaje: `Envía al menos uno de estos campos: ${campos.join(', ')}` },
      ])
    );
  };
}

const reglasId = [param('id').isMongoId().withMessage('El id del plan no es válido')];

module.exports = { exigirAlgunCampo, reglasId };
