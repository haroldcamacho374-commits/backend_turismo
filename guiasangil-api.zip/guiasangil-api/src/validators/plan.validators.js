const { body, query } = require('express-validator');
const { normalizarTexto } = require('../utils/texto');

const CAMPOS_CONSULTA = [
  'tipoActividad',
  'presupuesto',
  'tiempoDisponible',
  'nivelAdrenalina',
  'acompanantes',
  'mensaje',
];

const textoOpcional = (campo, max, etiqueta) =>
  body(campo)
    .optional({ values: 'falsy' })
    .isString().withMessage(`${etiqueta} debe ser texto`).bail()
    .trim()
    .isLength({ max }).withMessage(`${etiqueta} no puede superar los ${max} caracteres`);

const reglasCrearPlan = [
  textoOpcional('tipoActividad', 100, 'El tipo de actividad'),

  body('presupuesto')
    .optional({ values: 'null' })
    .isInt({ min: 0, max: 100000000 })
    .withMessage('El presupuesto debe ser un número entero en pesos colombianos (COP), entre 0 y 100.000.000')
    .toInt(),

  textoOpcional('tiempoDisponible', 100, 'El tiempo disponible'),

  body('nivelAdrenalina')
    .optional({ values: 'falsy' })
    .isString().withMessage('El nivel de adrenalina debe ser texto').bail()
    .customSanitizer(normalizarTexto)
    .isIn(['bajo', 'medio', 'alto']).withMessage('El nivel de adrenalina debe ser: bajo, medio o alto'),

  textoOpcional('acompanantes', 100, 'Los acompañantes'),
  textoOpcional('mensaje', 500, 'El mensaje'),
];

const reglasListado = [
  query('pagina').optional().isInt({ min: 1 }).withMessage('"pagina" debe ser un entero mayor o igual a 1').toInt(),
  query('limite').optional().isInt({ min: 1, max: 50 }).withMessage('"limite" debe ser un entero entre 1 y 50').toInt(),
];

module.exports = { CAMPOS_CONSULTA, reglasCrearPlan, reglasListado };
