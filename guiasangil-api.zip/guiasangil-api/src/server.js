const config = require('./config/env'); // carga dotenv y valida variables
const mongoose = require('mongoose');
const conectarDB = require('./config/db');
const app = require('./app');

let servidor;

async function iniciar() {
  try {
    await conectarDB();
    servidor = app.listen(config.port, () => {
      console.log(`GuíaSanGil API escuchando en el puerto ${config.port} (${config.nodeEnv})`);
    });
  } catch (error) {
    console.error('No se pudo iniciar el servidor:', error.message);
    process.exit(1);
  }
}

// Un error asíncrono no capturado se registra, pero no tumba el servidor
process.on('unhandledRejection', (motivo) => {
  console.error('Promesa rechazada sin manejar:', motivo);
});

// Estado impredecible: registrar y salir (el gestor de procesos reinicia la app)
process.on('uncaughtException', (error) => {
  console.error('Excepción no capturada:', error);
  process.exit(1);
});

// Cierre ordenado (Render envía SIGTERM al reiniciar/desplegar)
async function apagar() {
  console.log('Cerrando servidor...');
  if (servidor) servidor.close();
  await mongoose.connection.close();
  process.exit(0);
}
process.on('SIGTERM', apagar);
process.on('SIGINT', apagar);

iniciar();
