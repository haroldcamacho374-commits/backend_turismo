const config = require('../config/env');
const AppError = require('../utils/AppError');

// 404 para rutas inexistentes
function rutaNoEncontrada(req, _res, next) {
  next(new AppError(`Ruta no encontrada: ${req.method} ${req.originalUrl}`, 404));
}

// Manejo centralizado de errores: siempre responde JSON con el código HTTP apropiado.
// eslint-disable-next-line no-unused-vars
function manejarErrores(err, req, res, _next) {
  let status = err.statusCode || 500;
  let mensaje = err.message;
  let errores = err.errores;

  // JSON malformado en el body
  if (err.type === 'entity.parse.failed') {
    status = 400;
    mensaje = 'El cuerpo de la petición no es un JSON válido';
  }
  // Body demasiado grande
  else if (err.type === 'entity.too.large') {
    status = 413;
    mensaje = 'El cuerpo de la petición es demasiado grande';
  }
  // Errores de validación del esquema de Mongoose
  else if (err.name === 'ValidationError' && err.errors) {
    status = 400;
    mensaje = 'Datos de entrada inválidos';
    errores = Object.values(err.errors).map((e) => ({ campo: e.path, mensaje: e.message }));
  }
  // ObjectId mal formado
  else if (err.name === 'CastError') {
    status = 400;
    mensaje = `Valor inválido para el campo "${err.path}"`;
  }
  // Índice único violado (por ejemplo, correo repetido en una condición de carrera)
  else if (err.code === 11000) {
    status = 409;
    const campo = Object.keys(err.keyPattern || {})[0] || 'campo';
    mensaje = `Ya existe un registro con ese valor de "${campo}"`;
    errores = [{ campo, mensaje: `El ${campo} ya está registrado` }];
  }
  // JWT (por si algún error llega hasta aquí)
  else if (err.name === 'JsonWebTokenError' || err.name === 'TokenExpiredError') {
    status = 401;
    mensaje = err.name === 'TokenExpiredError' ? 'El token ha expirado' : 'Token inválido';
  }

  // Errores inesperados: se registran en el servidor y no se exponen detalles al cliente en producción
  if (status >= 500) {
    const traza = err.isOperational ? err.message : err;
    console.error(`[${new Date().toISOString()}] ${status} ${req.method} ${req.originalUrl}`, traza);
    if (config.nodeEnv === 'production' && !err.isOperational) {
      mensaje = 'Error interno del servidor';
    }
  }

  const cuerpo = { ok: false, mensaje };
  if (errores) cuerpo.errores = errores;
  if (config.nodeEnv !== 'production' && status >= 500) cuerpo.stack = err.stack;

  res.status(status).json(cuerpo);
}

module.exports = { rutaNoEncontrada, manejarErrores };
