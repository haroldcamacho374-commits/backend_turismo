const { validationResult } = require('express-validator');
const AppError = require('../utils/AppError');

// Revisa el resultado de las reglas de express-validator y responde 400 con el detalle por campo.
function validar(req, _res, next) {
  const resultado = validationResult(req);
  if (resultado.isEmpty()) return next();

  const errores = resultado.array({ onlyFirstError: true }).map((e) => ({
    campo: e.path || 'body',
    mensaje: e.msg,
  }));

  next(new AppError('Datos de entrada inválidos', 400, errores));
}

module.exports = validar;
