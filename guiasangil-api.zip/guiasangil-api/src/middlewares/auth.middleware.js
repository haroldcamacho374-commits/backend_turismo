const jwt = require('jsonwebtoken');
const config = require('../config/env');
const Usuario = require('../models/Usuario');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

// Protege rutas: exige "Authorization: Bearer <token>" con un JWT válido y vigente.
const proteger = asyncHandler(async (req, _res, next) => {
  const cabecera = req.headers.authorization || '';
  const [esquema, token] = cabecera.split(' ');

  if (esquema !== 'Bearer' || !token) {
    throw new AppError('No autenticado: envía el token en el header Authorization (Bearer <token>)', 401);
  }

  let payload;
  try {
    payload = jwt.verify(token, config.jwtSecret);
  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      throw new AppError('El token ha expirado, inicia sesión de nuevo', 401);
    }
    throw new AppError('Token inválido', 401);
  }

  // Confirma que el usuario aún existe
  const usuario = await Usuario.findById(payload.sub);
  if (!usuario) {
    throw new AppError('El usuario del token ya no existe', 401);
  }

  req.usuario = usuario;
  next();
});

module.exports = { proteger };
