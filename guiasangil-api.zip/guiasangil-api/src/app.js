const express = require('express');
const authRoutes = require('./routes/auth.routes');
const perfilRoutes = require('./routes/perfil.routes');
const planRoutes = require('./routes/plan.routes');
const { rutaNoEncontrada, manejarErrores } = require('./middlewares/error.middleware');

const app = express();

app.disable('x-powered-by');
app.use(express.json({ limit: '10kb' }));

app.get('/', (_req, res) => {
  res.json({
    ok: true,
    nombre: 'GuíaSanGil API',
    descripcion: 'Recomendaciones turísticas con IA para San Gil, Santander',
    documentacion: 'Ver README.md',
  });
});

// Health check (útil para Render)
app.get('/api/health', (_req, res) => {
  res.json({ ok: true, estado: 'operativo' });
});

app.use('/api/auth', authRoutes);
app.use('/api/perfil', perfilRoutes);
app.use('/api/planes', planRoutes);

app.use(rutaNoEncontrada);
app.use(manejarErrores);

module.exports = app;
