const mongoose = require('mongoose');
const config = require('./env');

async function conectarDB() {
  await mongoose.connect(config.mongodbUri);
  console.log('MongoDB conectado');
}

module.exports = conectarDB;
