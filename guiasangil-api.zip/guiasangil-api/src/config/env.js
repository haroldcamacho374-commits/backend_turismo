// Carga las variables de entorno con dotenv y valida las obligatorias al arrancar.
require('dotenv').config({ quiet: true });

const requeridas = ['MONGODB_URI', 'JWT_SECRET', 'GEMINI_API_KEY'];
const faltantes = requeridas.filter((nombre) => !process.env[nombre]);

if (faltantes.length > 0) {
  console.error(
    `Faltan variables de entorno obligatorias: ${faltantes.join(', ')}.\n` +
      'Revisa el archivo .env.example y crea tu archivo .env.'
  );
  process.exit(1);
}

if (process.env.JWT_SECRET.length < 32) {
  console.error('JWT_SECRET es muy corta: usa al menos 32 caracteres.');
  process.exit(1);
}

module.exports = {
  port: Number(process.env.PORT) || 3000,
  nodeEnv: process.env.NODE_ENV || 'development',
  mongodbUri: process.env.MONGODB_URI,
  jwtSecret: process.env.JWT_SECRET,
  // Si es solo un número ("3600") se interpreta como segundos; si trae unidad ("1d", "15m") se usa tal cual
  jwtExpiresIn: /^\d+$/.test(process.env.JWT_EXPIRES_IN || '')
    ? Number(process.env.JWT_EXPIRES_IN)
    : process.env.JWT_EXPIRES_IN || '1d',
  bcryptSaltRounds: Number(process.env.BCRYPT_SALT_ROUNDS) || 10,
  geminiApiKey: process.env.GEMINI_API_KEY,
  geminiModel: process.env.GEMINI_MODEL || 'gemini-3.1-flash-lite',
};
