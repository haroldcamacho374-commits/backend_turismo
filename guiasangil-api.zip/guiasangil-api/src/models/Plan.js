const mongoose = require('mongoose');

// "Plan guardado": consulta + respuesta de la IA + fecha, asociado a un usuario.
const planSchema = new mongoose.Schema(
  {
    usuario: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Usuario',
      required: true,
      index: true,
    },
    consulta: {
      tipoActividad: { type: String, trim: true },
      presupuesto: { type: Number, min: 0 },
      tiempoDisponible: { type: String, trim: true },
      nivelAdrenalina: { type: String, enum: ['bajo', 'medio', 'alto'] },
      acompanantes: { type: String, trim: true },
      mensaje: { type: String, trim: true },
    },
    respuesta: { type: String, required: true },
    modelo: { type: String }, // modelo de Gemini que generó la respuesta
  },
  {
    // "fecha" = momento en que se generó y guardó el plan
    timestamps: { createdAt: 'fecha', updatedAt: false },
    collection: 'planes',
    versionKey: false,
  }
);

planSchema.index({ usuario: 1, fecha: -1 });

module.exports = mongoose.model('Plan', planSchema);
