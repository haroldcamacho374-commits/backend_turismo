const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const config = require('../config/env');

const INTERESES_PERMITIDOS = ['aventura', 'naturaleza', 'gastronomia', 'cultura'];

const usuarioSchema = new mongoose.Schema(
  {
    nombre: { type: String, required: true, trim: true, maxlength: 80 },
    correo: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
    },
    // select:false => nunca se devuelve en las consultas salvo que se pida explícitamente
    contrasena: { type: String, required: true, select: false },
    // Perfil de viajero (se inyecta en el prompt enviado a la IA)
    perfil: {
      intereses: {
        type: [{ type: String, enum: INTERESES_PERMITIDOS }],
        default: [],
      },
      presupuesto: { type: Number, min: 0, default: null }, // COP aproximados
    },
  },
  { timestamps: true, collection: 'usuarios', versionKey: false }
);

// Hashea la contraseña con bcryptjs antes de persistirla (nunca se guarda en texto plano)
usuarioSchema.pre('save', async function () {
  if (!this.isModified('contrasena')) return;
  this.contrasena = await bcrypt.hash(this.contrasena, config.bcryptSaltRounds);
});

usuarioSchema.methods.compararContrasena = function (contrasenaPlana) {
  return bcrypt.compare(contrasenaPlana, this.contrasena);
};

// Evita filtrar la contraseña al serializar a JSON
usuarioSchema.set('toJSON', {
  transform: (_doc, ret) => {
    delete ret.contrasena;
    return ret;
  },
});

const Usuario = mongoose.model('Usuario', usuarioSchema);

module.exports = Usuario;
module.exports.INTERESES_PERMITIDOS = INTERESES_PERMITIDOS;
