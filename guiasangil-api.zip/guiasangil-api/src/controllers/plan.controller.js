const { matchedData } = require('express-validator');
const Plan = require('../models/Plan');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');
const { SYSTEM_INSTRUCTION, construirPrompt } = require('../services/prompt.service');
const { generarRecomendacion } = require('../services/gemini.service');

// POST /api/planes  -> consulta a Gemini y guarda el plan
const crearPlan = asyncHandler(async (req, res) => {
  const consulta = matchedData(req);

  // El perfil de viajero del usuario se incluye automáticamente en el prompt
  const prompt = construirPrompt({ perfil: req.usuario.perfil, consulta });
  const { texto, modelo } = await generarRecomendacion({
    systemInstruction: SYSTEM_INSTRUCTION,
    prompt,
  });

  const plan = await Plan.create({
    usuario: req.usuario._id,
    consulta,
    respuesta: texto,
    modelo,
  });

  res.status(201).json({ ok: true, mensaje: 'Plan generado y guardado', data: { plan } });
});

// GET /api/planes  -> historial del usuario autenticado (solo los suyos)
const listarPlanes = asyncHandler(async (req, res) => {
  const { pagina = 1, limite = 10 } = matchedData(req, { locations: ['query'] });
  const filtro = { usuario: req.usuario._id };

  const [planes, total] = await Promise.all([
    Plan.find(filtro)
      .sort({ fecha: -1 })
      .skip((pagina - 1) * limite)
      .limit(limite),
    Plan.countDocuments(filtro),
  ]);

  res.json({
    ok: true,
    data: {
      planes,
      paginacion: { pagina, limite, total, totalPaginas: Math.ceil(total / limite) },
    },
  });
});

// DELETE /api/planes/:id  -> solo si el plan pertenece al usuario autenticado
const eliminarPlan = asyncHandler(async (req, res) => {
  const plan = await Plan.findById(req.params.id);

  if (!plan) {
    throw new AppError('Plan no encontrado', 404);
  }
  if (!plan.usuario.equals(req.usuario._id)) {
    throw new AppError('No tienes permiso para eliminar este plan', 403);
  }

  await plan.deleteOne();
  res.json({ ok: true, mensaje: 'Plan eliminado correctamente' });
});

module.exports = { crearPlan, listarPlanes, eliminarPlan };
