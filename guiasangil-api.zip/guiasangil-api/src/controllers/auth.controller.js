const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { matchedData } = require('express-validator');
const config = require('../config/env');
const Usuario = require('../models/Usuario');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

// Hash de relleno: se compara cuando el correo no existe, para que el tiempo de respuesta
// no revele si el usuario está registrado.
const HASH_RELLENO = bcrypt.hashSync('contrasena-de-relleno', config.bcryptSaltRounds);

function firmarToken(usuario) {
  return jwt.sign({ sub: usuario.id }, config.jwtSecret, { expiresIn: config.jwtExpiresIn });
}

// POST /api/auth/registro
const registro = asyncHandler(async (req, res) => {
  const { nombre, correo, contrasena } = matchedData(req);

  // La contraseña se hashea con bcryptjs en el hook pre('save') del modelo
  const usuario = await Usuario.create({ nombre, correo, contrasena });

  res.status(201).json({
    ok: true,
    mensaje: 'Usuario registrado correctamente',
    data: { usuario },
  });
});

// POST /api/auth/login
const login = asyncHandler(async (req, res) => {
  const { correo, contrasena } = matchedData(req);

  const usuario = await Usuario.findOne({ correo }).select('+contrasena');
  const coincide = usuario
    ? await usuario.compararContrasena(contrasena)
    : await bcrypt.compare(contrasena, HASH_RELLENO);

  if (!usuario || !coincide) {
    throw new AppError('Correo o contraseña incorrectos', 401);
  }

  res.json({
    ok: true,
    mensaje: 'Inicio de sesión exitoso',
    data: {
      token: firmarToken(usuario),
      tipo: 'Bearer',
      expiraEn: config.jwtExpiresIn,
      usuario,
    },
  });
});

module.exports = { registro, login };
