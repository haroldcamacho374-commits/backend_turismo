const { matchedData } = require('express-validator');
const Usuario = require('../models/Usuario');
const asyncHandler = require('../utils/asyncHandler');

// GET /api/perfil
const obtenerPerfil = asyncHandler(async (req, res) => {
  res.json({ ok: true, data: { usuario: req.usuario } });
});

// PUT /api/perfil
const actualizarPerfil = asyncHandler(async (req, res) => {
  const datos = matchedData(req, { includeOptionals: true });

  const cambios = {};
  if (datos.intereses !== undefined) cambios['perfil.intereses'] = datos.intereses;
  if (datos.presupuesto !== undefined) cambios['perfil.presupuesto'] = datos.presupuesto; // null lo borra

  const usuario = await Usuario.findByIdAndUpdate(
    req.usuario._id,
    { $set: cambios },
    { new: true, runValidators: true }
  );

  res.json({ ok: true, mensaje: 'Perfil de viajero actualizado', data: { usuario } });
});

module.exports = { obtenerPerfil, actualizarPerfil };
