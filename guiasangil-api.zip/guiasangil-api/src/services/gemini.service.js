// Consumo de la API de Gemini (REST) desde el backend. La API key nunca sale del servidor.
const config = require('../config/env');
const AppError = require('../utils/AppError');

const BASE_URL = 'https://generativelanguage.googleapis.com/v1beta/models';
const TIMEOUT_MS = 30000;

async function generarRecomendacion({ systemInstruction, prompt }) {
  const url = `${BASE_URL}/${encodeURIComponent(config.geminiModel)}:generateContent`;

  let respuesta;
  try {
    respuesta = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-goog-api-key': config.geminiApiKey,
      },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: systemInstruction }] },
        contents: [{ role: 'user', parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0.7, maxOutputTokens: 2048 },
      }),
      signal: AbortSignal.timeout(TIMEOUT_MS),
    });
  } catch (error) {
    if (error.name === 'TimeoutError' || error.name === 'AbortError') {
      throw new AppError('El asistente de IA tardó demasiado en responder. Intenta de nuevo', 504);
    }
    console.error('Error de red al contactar Gemini:', error.message);
    throw new AppError('No se pudo contactar al asistente de IA', 502);
  }

  if (!respuesta.ok) {
    const detalle = await respuesta.json().catch(() => null);
    console.error(`Gemini respondió ${respuesta.status}:`, detalle?.error?.message || 'sin detalle');

    if (respuesta.status === 429) {
      throw new AppError('El asistente de IA está recibiendo muchas solicitudes. Intenta de nuevo en un minuto', 429);
    }
    throw new AppError('El asistente de IA no pudo generar la recomendación en este momento', 502);
  }

  const data = await respuesta.json();

  if (data.promptFeedback?.blockReason) {
    throw new AppError('La consulta fue bloqueada por los filtros de seguridad de la IA. Reformúlala', 422);
  }

  const partes = data.candidates?.[0]?.content?.parts || [];
  const texto = partes
    .filter((p) => typeof p.text === 'string' && !p.thought)
    .map((p) => p.text)
    .join('')
    .trim();

  if (!texto) {
    throw new AppError('La IA no devolvió una respuesta. Intenta de nuevo', 502);
  }

  return { texto, modelo: config.geminiModel };
}

module.exports = { generarRecomendacion };
