const { Router } = require('express');
const { obtenerPerfil, actualizarPerfil } = require('../controllers/perfil.controller');
const { reglasActualizarPerfil } = require('../validators/perfil.validators');
const { exigirAlgunCampo } = require('../validators/comunes');
const { proteger } = require('../middlewares/auth.middleware');
const validar = require('../middlewares/validar.middleware');

const router = Router();

router.use(proteger); // todas las rutas de perfil requieren JWT

router.get('/', obtenerPerfil);
router.put(
  '/',
  exigirAlgunCampo(['intereses', 'presupuesto'], { aceptarNull: true }),
  reglasActualizarPerfil,
  validar,
  actualizarPerfil
);

module.exports = router;
