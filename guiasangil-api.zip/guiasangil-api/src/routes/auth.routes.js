const { Router } = require('express');
const { registro, login } = require('../controllers/auth.controller');
const { reglasRegistro, reglasLogin } = require('../validators/auth.validators');
const validar = require('../middlewares/validar.middleware');

const router = Router();

router.post('/registro', reglasRegistro, validar, registro);
router.post('/login', reglasLogin, validar, login);

module.exports = router;
