const { Router } = require('express');
const { crearPlan, listarPlanes, eliminarPlan } = require('../controllers/plan.controller');
const { CAMPOS_CONSULTA, reglasCrearPlan, reglasListado } = require('../validators/plan.validators');
const { exigirAlgunCampo, reglasId } = require('../validators/comunes');
const { proteger } = require('../middlewares/auth.middleware');
const validar = require('../middlewares/validar.middleware');

const router = Router();

router.use(proteger); // todas las rutas de planes requieren JWT

router.post('/', exigirAlgunCampo(CAMPOS_CONSULTA), reglasCrearPlan, validar, crearPlan);
router.get('/', reglasListado, validar, listarPlanes);
router.delete('/:id', reglasId, validar, eliminarPlan);

module.exports = router;
