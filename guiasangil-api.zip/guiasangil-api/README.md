# GuíaSanGil API 🏞️

Backend REST de **GuíaSanGil**: los turistas se registran, inician sesión y le piden recomendaciones personalizadas a un asistente de inteligencia artificial (Gemini) sobre qué hacer en **San Gil, Curití, Barichara, Mogotes** y el cañón de los ríos **Fonce** y **Suárez** (Santander, Colombia). Cada recomendación queda guardada como un **plan** en el historial privado del usuario.

- **Producción (Render):** `https://TU-APP.onrender.com` ← reemplazar con la URL real
- **Repositorio:** `https://github.com/TU-USUARIO/guiasangil-api` ← reemplazar con el link real

> En el plan gratuito de Render la instancia "duerme" tras un rato de inactividad: la primera petición puede tardar ~50 segundos en responder.

## Stack

Node.js (JavaScript puro) · Express · MongoDB + Mongoose · dotenv · express-validator · bcryptjs · jsonwebtoken · Gemini API (consumida con el `fetch` nativo de Node, sin dependencias extra).

## Estructura del proyecto

```
guiasangil-api/
├── src/
│   ├── config/         # env.js (dotenv + validación de variables), db.js (Mongoose)
│   ├── models/         # Usuario.js, Plan.js
│   ├── validators/     # reglas de express-validator por recurso
│   ├── middlewares/    # auth (JWT), validar, manejo centralizado de errores
│   ├── controllers/    # auth, perfil, plan
│   ├── routes/         # auth.routes, perfil.routes, plan.routes
│   ├── services/       # gemini.service.js (API de IA), prompt.service.js (prompt con contexto regional)
│   ├── utils/          # AppError, asyncHandler, texto
│   ├── app.js          # configuración de Express
│   └── server.js       # arranque: conexión a BD y listen
├── .env.example
├── render.yaml         # Blueprint opcional para Render
└── package.json
```

## Instalación local

Requisitos: Node.js 20+ y una base MongoDB (local o un cluster gratuito de [MongoDB Atlas](https://www.mongodb.com/atlas)).

```bash
git clone https://github.com/TU-USUARIO/guiasangil-api.git
cd guiasangil-api
npm install
cp .env.example .env        # en Windows: copy .env.example .env
# edita .env con tus valores reales
npm run dev                 # desarrollo (reinicia al guardar)
npm start                   # producción
```

La API queda en `http://localhost:3000`.

## Variables de entorno

Documentadas en [`.env.example`](.env.example). **Nunca subas tu `.env`** (ya está en `.gitignore`).

| Variable | Obligatoria | Descripción |
|---|---|---|
| `PORT` | No | Puerto local (Render lo asigna solo). Por defecto `3000`. |
| `NODE_ENV` | No | `development` o `production`. En producción no se exponen detalles de errores 500. |
| `MONGODB_URI` | **Sí** | Cadena de conexión a MongoDB. |
| `JWT_SECRET` | **Sí** | Clave para firmar los JWT (mínimo 32 caracteres). Generar con `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`. |
| `JWT_EXPIRES_IN` | No | Duración del token: `15m`, `1h`, `1d`, `7d`… Por defecto `1d`. |
| `BCRYPT_SALT_ROUNDS` | No | Rondas de salt de bcryptjs. Por defecto `10`. |
| `GEMINI_API_KEY` | **Sí** | API key de Gemini, gratis en [Google AI Studio](https://aistudio.google.com/apikey). |
| `GEMINI_MODEL` | No | Modelo de Gemini. Por defecto `gemini-3.1-flash-lite`. |

> **Sobre el modelo:** `gemini-pro` ya fue retirado y la familia Gemini 2.5 tiene fecha de apagado anunciada (16 de octubre de 2026). Por eso el modelo es configurable con `GEMINI_MODEL`. Si cambia la disponibilidad o la capa gratuita, revisa la [lista de modelos](https://ai.google.dev/gemini-api/docs/models) y ajusta la variable, sin tocar código.

El servidor **no arranca** si falta alguna variable obligatoria y avisa cuál.

## Formato de respuestas

Éxito:

```json
{ "ok": true, "mensaje": "...", "data": { } }
```

Error (siempre JSON, con el código HTTP apropiado):

```json
{
  "ok": false,
  "mensaje": "Datos de entrada inválidos",
  "errores": [
    { "campo": "contrasena", "mensaje": "La contraseña debe incluir al menos una letra mayúscula" }
  ]
}
```

| Código | Cuándo |
|---|---|
| 400 | Datos inválidos, JSON malformado, id mal formado |
| 401 | Sin token, token inválido/expirado, credenciales incorrectas |
| 403 | El recurso existe pero pertenece a otro usuario |
| 404 | Ruta o recurso inexistente |
| 409 | Valor único duplicado detectado por la base de datos |
| 413 | Cuerpo de la petición demasiado grande |
| 422 | La IA bloqueó la consulta por sus filtros de seguridad |
| 429 | La API de Gemini alcanzó su límite de uso |
| 502 / 504 | Falla o tiempo de espera del servicio de IA |
| 500 | Error interno inesperado |

## Endpoints

Las rutas marcadas con 🔒 requieren el header `Authorization: Bearer <token>`.

| Método | Ruta | Descripción |
|---|---|---|
| GET | `/api/health` | Estado del servicio |
| POST | `/api/auth/registro` | Registrar un turista |
| POST | `/api/auth/login` | Iniciar sesión y obtener JWT |
| GET | `/api/perfil` 🔒 | Ver mi perfil de viajero |
| PUT | `/api/perfil` 🔒 | Editar intereses y presupuesto |
| POST | `/api/planes` 🔒 | Consultar a la IA y guardar el plan |
| GET | `/api/planes` 🔒 | Listar mi historial de planes |
| DELETE | `/api/planes/:id` 🔒 | Eliminar uno de mis planes |

### `POST /api/auth/registro`

```json
{ "nombre": "Ana Pérez", "correo": "ana@correo.co", "contrasena": "Clave1234" }
```

Reglas: nombre de 2 a 80 caracteres; correo válido y único; contraseña de 8 a 72 caracteres con al menos una mayúscula y un número. Respuesta `201` con el usuario (nunca incluye la contraseña). La contraseña se guarda hasheada con bcryptjs.

### `POST /api/auth/login`

```json
{ "correo": "ana@correo.co", "contrasena": "Clave1234" }
```

Respuesta `200`:

```json
{
  "ok": true,
  "mensaje": "Inicio de sesión exitoso",
  "data": { "token": "eyJhbGciOi...", "tipo": "Bearer", "expiraEn": "1d", "usuario": { } }
}
```

### `PUT /api/perfil` 🔒

```json
{ "intereses": ["aventura", "gastronomia"], "presupuesto": 150000 }
```

- `intereses`: lista con valores de `aventura`, `naturaleza`, `gastronomia`, `cultura` (se aceptan mayúsculas y tildes; se eliminan duplicados).
- `presupuesto`: entero en pesos colombianos (COP). Envía `null` para borrarlo.
- Debes enviar al menos uno de los dos campos.

Estas preferencias se incluyen **automáticamente** en el prompt que se envía a Gemini.

### `POST /api/planes` 🔒

Todos los campos son opcionales, pero debes enviar al menos uno:

```json
{
  "mensaje": "Quiero algo de adrenalina y tengo medio día",
  "tipoActividad": "aventura",
  "presupuesto": 120000,
  "tiempoDisponible": "medio día",
  "nivelAdrenalina": "alto",
  "acompanantes": "pareja"
}
```

- `nivelAdrenalina`: `bajo`, `medio` o `alto`.
- `presupuesto` de la consulta tiene prioridad sobre el del perfil.

Respuesta `201`:

```json
{
  "ok": true,
  "mensaje": "Plan generado y guardado",
  "data": {
    "plan": {
      "_id": "...",
      "usuario": "...",
      "consulta": { "mensaje": "...", "nivelAdrenalina": "alto" },
      "respuesta": "## Plan de aventura en San Gil\n...",
      "modelo": "gemini-3.1-flash-lite",
      "fecha": "2026-10-02T15:30:00.000Z"
    }
  }
}
```

### `GET /api/planes` 🔒

Devuelve solo los planes del usuario autenticado, del más reciente al más antiguo. Parámetros opcionales: `?pagina=1&limite=10` (límite máximo 50).

### `DELETE /api/planes/:id` 🔒

`200` si se eliminó, `404` si no existe, `403` si el plan pertenece a otro usuario, `400` si el id no es válido.

## Prueba rápida con curl

```bash
BASE=http://localhost:3000

curl -X POST $BASE/api/auth/registro -H "Content-Type: application/json" \
  -d '{"nombre":"Ana Pérez","correo":"ana@correo.co","contrasena":"Clave1234"}'

TOKEN=$(curl -s -X POST $BASE/api/auth/login -H "Content-Type: application/json" \
  -d '{"correo":"ana@correo.co","contrasena":"Clave1234"}' | node -pe "JSON.parse(require('fs').readFileSync(0)).data.token")

curl -X PUT $BASE/api/perfil -H "Content-Type: application/json" -H "Authorization: Bearer $TOKEN" \
  -d '{"intereses":["aventura","gastronomia"],"presupuesto":150000}'

curl -X POST $BASE/api/planes -H "Content-Type: application/json" -H "Authorization: Bearer $TOKEN" \
  -d '{"mensaje":"Quiero algo de adrenalina y tengo medio día"}'

curl $BASE/api/planes -H "Authorization: Bearer $TOKEN"
```

También puedes probar todo con Postman o Thunder Client.

## Despliegue en Render

1. Sube el proyecto a un repositorio público de GitHub (verifica que `.env` **no** esté incluido).
2. Crea una base gratuita en MongoDB Atlas, un usuario de base de datos y, en *Network Access*, permite el acceso desde `0.0.0.0/0` (Render usa IPs variables en el plan gratuito).
3. En [render.com](https://render.com): **New → Web Service** → conecta tu repositorio.
   - **Runtime:** Node
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - **Instance Type:** Free
   - **Health Check Path:** `/api/health`
4. En **Environment** agrega: `MONGODB_URI`, `JWT_SECRET`, `GEMINI_API_KEY`, `NODE_ENV=production` y, opcionalmente, `JWT_EXPIRES_IN`, `BCRYPT_SALT_ROUNDS`, `GEMINI_MODEL`.
5. Despliega y prueba `https://TU-APP.onrender.com/api/health`.

(Alternativa: el archivo `render.yaml` permite crear el servicio como *Blueprint*; los secretos se piden en el panel, no están en el repositorio.)

## Seguridad aplicada

- Contraseñas hasheadas con bcryptjs; el campo `contrasena` no se devuelve nunca en las consultas ni en el JSON.
- JWT firmado con secreto en variable de entorno y con expiración configurable; el middleware rechaza tokens ausentes, inválidos y expirados.
- Login con mensaje genérico ("Correo o contraseña incorrectos") y comparación de hash también cuando el correo no existe, para no revelar qué usuarios están registrados.
- Los campos se validan como texto antes de consultar la base de datos (evita inyección NoSQL del tipo `{"$gt": ""}`).
- Cada usuario solo accede a sus propios planes; el borrado verifica propiedad.
- Secretos solo en variables de entorno; `.env` ignorado por git; la API key de Gemini viaja en un header y nunca llega al cliente.
- Prompt de la IA con instrucciones para no inventar precios/horarios, recordar medidas de seguridad en deportes extremos e ignorar intentos de cambiar su rol.
- Límite de 10 KB en el cuerpo de las peticiones y detalles de errores 500 ocultos en producción.

## Mejoras posibles (fuera del alcance del ejercicio)

`helmet`, `cors` y `express-rate-limit` (especialmente en `POST /api/planes` para controlar el consumo de la API de IA), pruebas automatizadas con Jest/Supertest y documentación OpenAPI/Swagger.
